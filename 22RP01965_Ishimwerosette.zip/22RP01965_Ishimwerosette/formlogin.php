<?php
session_start();
if(!($_SESSION['username']))
{
	header("location:login.php");
}
?>
<?php
$username=$password="";
$usernameErr="";
$passwordErr="";
function test_input($input)
{
    $input=trim($input);
    $input=stripslashes($input);
    $input=htmlspecialchars($input);
    return $input;  
}
if($_SERVER['REQUEST_METHOD']=='POST')
{
if(empty($_POST['username'])){
$usernameErr='Username is Required';
}
else{
    $username =test_input($_POST['username']);
    if(!preg_match('/^[A-Za-z]+$/',$username))
    {
$usernameErr='Invalid Username';
}
}
if(empty($_POST['password']))
{
    $passwordErr= 'Password is required';
}
else{
    $password =test_input($_POST['password']);
if(!preg_match('/^[A-Za-z0-9]{8,}$/',$password))
{
    $passwordErr= 'Invalid Password!';
}}

}

?>

<!doctype html>
<!DOCTYPE html>
<html>
<head>
	<title>
		login form
	</title>
</head>
<body>
	<h2>Login form</h2>
<form action="form.php"method="post">
	  <fieldset style="width: 300px;background-color: blue">
	username:<input type="text"name="username"><br><I><?php echo $lastnameErr?></I><br>
	password:<input type="password"name="password"><I><?php echo $lastnameErr?></I><br><br>
	<input type="submit" name="login" value="login">
</form>
<?php
include('connection.php');
    if(isset($_POST['send']))
    {
        $username=$_POST['username'];
        $password=$_POST['password'];
        $query=mysqli_query($a,"insert into users(username,password) values('$username','$password')");
        if($query==true)
        {
            echo"data is inserted";
        }
        else{
            echo"Insertion Failed";
        }
        
}
?>
</body>
</html>.
