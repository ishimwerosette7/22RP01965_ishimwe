<?php
require 'connection.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home page</title>
   <style>
   .header{
			width: 100%;
			height: 80px;
			border: 1px solid black;
			background-color:lightgreen ;
		}
		.nav{
			width: 20%;
			height: 370px;
			border: 1px solid black;
			margin: 15px;
			background-color: lightgreen;
			float: left;

		}
		.nav2{
			width: 74%;
			height: 370px;
			border: 1px solid black;
			margin: 15px;
			background-color: lightgreen;
			float: left;

		}
		.nav ul li{
			display: block;
			padding: 20px;
		}
		.nav ul li a{
			text-decoration: none;
		}
		.body{
			width: 100%;
			height: 400px;
			border: 1px solid black;
			background-color: lightgreen;

		}
		.footer{
			width: 100%;
			height: 80px;
			border: 1px solid black;
			background-color: lightgreen;

		}
		
	</style>
</head>
<body>
    <div class="header">
    <h2>Welcome to Student Management System 
    </h2>
    </div>
    
    <div class="body">
    <div class="nav">
        <h2>Navigation Menu</h2>
		<ul>
			<li><a href="form.php">form</a></li>
			<li><a href="formlogin.php">formlogin</a></li>
				<li><a href="select.php">select Student</a></li>
		</ul>
    </div>
    <div class="nav2">
        <?php
        $id=$_GET['id'];
        $select="SELECT * FROM student WHERE id=$id";
        $q=mysqli_query($a,$select);
        while($row=mysqli_fetch_assoc($q)){
        ?>
        <center>
            <form action="#" method="POST">
            <h2>Update Student Information</h2>
            
                    <label>Firstname:</label>
                    <input type="text" name="firstname" required value="<?php echo $row['firstname']; ?>"><br><br>
                    <label>Lastname:</label>
                    <input type="text" name="lastname" required value="<?php echo $row['lastname']; ?>"><br><br>
                    <label>age:</label>
                    <input type="number" name="age" required value="<?php echo $row['age'] ?>"><br><br>
                    <label>Gender:</label>
                    <input type="radio" name="Gender" value="Male"<?php if(isset($row['Gender']) && $row['Gender']=='Male')echo 'checked' ;  ?>>Male &nbsp;&nbsp;
                    <input type="radio" name="gender" value="Female"<?php if(isset($row['Gender'])&& $row['Gender']=='Female')echo 'checked'; ?>>Female<br><br><br>
                    <label>Email</label>
                     <input type="Email" name="Email" required value="<?php echo $row['Email']; ?>"><br><br>
                
                
                <input type="submit" name="update" value="Update Student">
            
            
                </form>
           
        </center>
        <?php } ?>
    </div>
    </div>
    <div id="footer">

    <center>
        <h1>&copy; Rosette ishimwe</h1>
    </center>
    </div>
</body>
</html>
<?php 
require 'connection.php';
if(isset($_POST['update'])){
   $id=$_GET['id'];
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $age=$_POST['age'];
    $Gender=$_POST['Gender'];
    $Email=$_POST['Email'];
    $update="UPDATE student SET firstname='$firstname',lastname='$lastname',age='$age',Gender='$Gender', Email='$Email' WHERE id='$id'";
    $q=mysqli_query($a,$update);
    if($q){
        echo"<script>alert('Student updated successfully');</script>";
        header("location:select.php");
    }
    else{
        echo"<script>alert('Failed to update student');</script>";
        header("Location:update.php");
    }
}




?>