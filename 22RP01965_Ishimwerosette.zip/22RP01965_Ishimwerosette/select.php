<?php
$conn =mysqli_connect("localhost", "root", "", "student_management");
$select=mysqli_query($conn,"SELECT * FROM STUDENT");
echo"<center><U>LIST OF ALL STUDENTS IN SCHOOL</U><br><br>";
echo"<table border='1' bgcolor='green'><th>id</TH><TH>firstname</TH><th>lastname</TH><TH>age</TH><th>Gender</TH><TH>Email</TH>


<TH colspan='2' bgcolor='blue'>ACTION</TH>";
while($fetch=mysqli_fetch_array($select))
{
     $id=$fetch['id'];
echo"<tr><td>".$fetch['id']."</td>";
echo"<td>".$fetch['firstname']."</td>";
echo"<td>".$fetch['lastname']."</td>";
echo"<td>".$fetch['age']."</td>";
echo"<td>".$fetch['Gender']."</td>";
echo"<td>".$fetch['Email']."</td>";
echo"<td bgcolor='pink'><a href='Update.php?id=$id'>Update"."</td>";
echo"<td bgcolor='pink'><a href='Delete.php?id=$id'> Delete"."</td>";
echo"</tr>";
}
echo"</table>";
echo "<a href='form.php'>form</a><hr>";
echo "<a href='logout.php'>logout</a>";
?>