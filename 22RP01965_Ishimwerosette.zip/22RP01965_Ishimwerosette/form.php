
<?php
$firstname=$lastname=$age=$Gender=$Email= "";
$firstnameErr="";
$lastnameErr="";
$ageErr="";
$GenderErr="";
$EmailErr="";
function test_input($input)
{
    $input=trim($input);
    $input=stripslashes($input);
    $input=htmlspecialchars($input);
    return $input;
    
}
if($_SERVER['REQUEST_METHOD']=='POST')
{
if(empty($_POST['firstname'])){
$firstnameErr='firstname is Required';
}
else{
    $firstname =test_input($_POST['firstname']);
    if(!preg_match('/^[A-Za-z]+$/',$username))
    {
$firstnameErr='Invalid firstname';
}
}
if(empty($_POST['lastname']))
{
    $lastnameErr= 'lastname is required';
}
else{
    $lastname=test_input($_POST['lastname']);
if(!preg_match('/^[A-Za-z0-9]{8,}$/',$lastname))
{
    $lastnameErr= 'Invalid lastname!';
}}if(empty($_POST['age'])){
$ageErr='age is Required';
}
else{
    $age =test_input($_POST['age']);
    if(!preg_match('/^[A-Za-z]+$/',$age))
    {
$ageErr='Invalid age';
}
}
if(empty($_POST['Gender']))
{
    $GenderErr= 'Gender is required';
}
else{
    $Gender=test_input($_POST['Gender']);
if(!preg_match('/^[A-Za-z0-9]{8,}$/',$Gender))
{
    $GenderErr= 'Invalid Gender!';
}}

if(empty($_POST['Email']))
{
    $EmailErr= 'Email is required';
}
else{
    $Email =test_input($_POST['Email']);
    if(!filter_var($Email, FILTER_VALIDATE_EMAIL))
    {
$EmailErr='Invalid email';
    }
}

}

?> 

<!DOCTYPE html>
<html>
<head>
    <title>Student Form</title>
</head>
<body>
    <h2>Student Form</h2>
    <form action="" method="post">
          <fieldset style="width: 300px;background-color: blue">
        <table>                
            <tr>
                <td>first Name:</td>
                <td><input type="text" name="firstname"><br><I><?php echo $lastnameErr?></I><br></td>
            </tr>
            <tr>
                <td>last Name:</td>
                <td><input type="text" name="lastname"><br><I><?php echo $lastnameErr?></I><br></td>
            </tr>
            <tr>
                <td>age:</td>
                <td><input type="number" name="age"><br><I><?php echo $lastnameErr?></I><br></td>
            </tr>
            <tr>
                <td>Gender:</td>
                <td>
                    <input type="radio" name="Gender" value="Female"> Female
                    <input type="radio" name="Gender" value="Male"> Male
                </td>
            </tr>
            <tr>
                <td>Email:</td>
                <td><input type="text" name="Email"><br><I><?php echo $lastnameErr?></I><br></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" name="send" value="Send">
                <input type="submit" name="clear" value="clear"></td>
            </tr>
        </table>
    </fieldset>
    </form>
    <?php
include('connection.php');
    if(isset($_POST['firstname'])&& isset($_POST['lastname']) && isset($_POST['Gender'])&&isset($_POST['age'])&&isset($_POST['Email']))
    {
        $firstname=$_POST['firstname'];
         $lastname=$_POST['lastname'];
        $age=$_POST['age'];
        $Gender=$_POST['Gender'];
        $Email=$_POST['Email'];
        $query=mysqli_query($a,"INSERT into student(firstname,lastname,age,Gender,Email) values('$firstname','$lastname','$age','$Gender','$Email')");
        if($query==true)
        {
            echo"data is inserted";
            header("location:select.php");
        }
        else{
            echo"Insertion Failed";
        }
        
}
?>
</body>
</html>